
library(devtools)
install_github("ayushgupta0110/test")
library(test)

x<- 1
y<- 5
addSum(x,y)
